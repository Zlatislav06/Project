﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurvivalWF
{
    internal class Food
    {
        public string Otter(string a)
        {
            if (a == "Fish") { return a; }
            else if (a == "Insects") { return a; }
            else { a = ""; return a; }


        }
        public string Cat(string a)
        {
            if (a == "Fish") { return a; }
            else if (a == "Meat") { return a; }
            else { a = ""; return a; }
        }
        public string Frog(string a)
        {
            if (a == "Insects") { return a; }
            else { a = ""; return a; }
        }
        public string Dog(string a)
        {
            if (a == "Fish") { return a; }
            else if (a == "Meat") { return a; }
            else { a = ""; return a; }
        }
        public string Camel(string a)
        {
            if (a == "Plant") { return a; }
            else { a = ""; return a; }

        }
        public string Lion(string a)
        {
            if (a == "Meat") { return a; }
            else if (a == "Fish") { return a; }
            else { a = ""; return a; }

        }
        public string Fish(string a)
        {

            if (a == "Plant") { return a; }
            else { a = ""; return a; }

        }
        public string Shark(string a)
        {
            if (a == "Fish") { return a; }
            else if (a == "Meat") { return a; }
            else { a = ""; return a; }

        }
        public string Snake(string a)
        {
            if (a == "Meat") { return a; }
            else { a = ""; return a; }
        }
        public string Eagle(string a)
        {
            if (a == "Meat") { return a; }
            else { a = ""; return a; }

        }
    }
}
