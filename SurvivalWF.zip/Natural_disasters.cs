﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurvivalWF
{
    internal class Natural_disasters
    {
        private int number;


        public int Number
        {
            get { return number; }
            set { number = value; }
        }
        public Natural_disasters(int number)
        {
            this.Number = number;
        }
        public void Otter()
        {
            MessageBox.Show(15 * Number + "лв. е цената за храната за определен период от време!");

        }
        public void Cat()
        {
            MessageBox.Show(1.15 * Number + "лв. е цената за храната за определен период от време!");
        }
        public void Frog()
        {

            MessageBox.Show(3 * Number + "лв. е цената за храната за определен период от време!");
        }
        public void Dog()
        {
            MessageBox.Show(4 * Number + "лв. е цената за храната за определен период от време!");

        }
        public void Camel()
        {

            MessageBox.Show(4.48 * Number + "лв. е цената за храната за определен период от време!");
        }
        public void Lion()
        {
            MessageBox.Show(7 * Number + "лв. е цената за храната за определен период от време!");
        }
        public void Fish()
        {
            MessageBox.Show(1 * Number + "лв. е цената за храната за определен период от време!");

        }
        public void Shark()
        {
            MessageBox.Show(10 * Number + "лв. е цената за храната за определен период от време!");

        }
        public void Snake()
        {

            MessageBox.Show(15 * Number + "лв. е цената за храната за определен период от време!");
        }
        public void Eagle()
        {
            MessageBox.Show(15 * Number + "лв. е цената за храната за определен период от време!");

        }
    }
}
