﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurvivalWF
{
    internal class Animals
    {
        public void Otter(string a)
        {
            
            
            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Not survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Not survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }


        }
        public void Cat(string a)
        {
            if (a == "Flood") { MessageBox.Show("Not survival"); }
            else if (a == "Drought") { MessageBox.Show("Not survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Not survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Frog(string a)
        {
            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Not survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Dog(string a)
        {
            if (a == "Flood") { MessageBox.Show("Not survival"); }
            else if (a == "Drought") { MessageBox.Show("Survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Not survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Camel(string a)
        {

            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Survival"); }
            else if (a == "Storm") { MessageBox.Show("Not survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Not survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Lion(string a)
        {

            if (a == "Flood") { MessageBox.Show("Not survival"); }
            else if (a == "Drought") { MessageBox.Show("Survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Not survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { Console.WriteLine("Това бедствие не е дадено!"); }
        }
        public void Fish(string a)
        {

            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Not survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Shark(string a)
        {

            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Not survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Snake(string a)
        {
            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Survival"); }
            else if (a == "Poison") { MessageBox.Show("Survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
        public void Eagle(string a)
        {
            if (a == "Flood") { MessageBox.Show("Survival"); }
            else if (a == "Drought") { MessageBox.Show("Survival"); }
            else if (a == "Storm") { MessageBox.Show("Survival"); }
            else if (a == "Earthquake") { MessageBox.Show("Survival"); }
            else if (a == "Poison") { MessageBox.Show("Not survival"); }
            else { MessageBox.Show("Това бедствие не е дадено!"); }
        }
    }
}
